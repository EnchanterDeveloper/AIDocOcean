# run docker container with port mapping
docker run -p 8080:8000 myphpapp:web

docker stop cont_name
docker rm cont_name
docker rmi myphpapp