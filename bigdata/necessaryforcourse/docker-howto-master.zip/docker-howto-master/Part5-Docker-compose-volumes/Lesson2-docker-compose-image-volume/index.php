<?php echo "hello docker-compose without Dockerfile\n\n";
