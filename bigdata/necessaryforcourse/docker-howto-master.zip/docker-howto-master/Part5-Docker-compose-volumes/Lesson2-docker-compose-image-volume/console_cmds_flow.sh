# start containers
docker-compose up
