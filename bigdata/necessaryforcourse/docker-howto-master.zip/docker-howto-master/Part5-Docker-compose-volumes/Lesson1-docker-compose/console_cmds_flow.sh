# start containers
docker-compose up

# build/rebuild container
docker-compo up --build

# stop and remove containers and networks
docker-compose down
